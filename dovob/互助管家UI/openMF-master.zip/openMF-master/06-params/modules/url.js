/**
 * Created by mfhj-dz-001-424 on 16/11/7.
 */

let commonUrl='http://172.16.32.70:8080/apistore/openapi';

export const Urllogin=commonUrl+'/login';
export const UrlInfo=commonUrl+'/account/merchant/query';
export const UrlApp=commonUrl+'/account/app/query/';
export const UrlService=commonUrl+'/account/apis/query/';