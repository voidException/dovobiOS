/**
 * Created by mfhj-dz-001-424 on 16/11/23.
 */

export const Login_userProfile='Login_userProfile';

export const Get_tuiwenPage='Get_tuiwenPage';
export const Get_tweetPage='Get_tweetPage';
export const Get_weiboPage='Get_weiboPage';
export const Get_itemPage='Get_itemPage';
export const Get_WheelImgs='Get_WheelImgs';